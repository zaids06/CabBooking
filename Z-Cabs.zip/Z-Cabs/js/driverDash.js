/**
 * Created by anurag1018 on 7/2/17.
 */
$(document).ready(function(){

    //check for active tab
    function activator() {
        if ($('ul li:nth-child(1)').hasClass("active")) {
            $('#accountInfoForm').css("display", "block");
        }
        if ($('ul li:nth-child(2)').hasClass("active")) {
            $('#addressBookForm').css("display", "block");
        }
        if ($('ul li:nth-child(3)').hasClass("active")) {
            $('#ordersForm').css("display", "block");
        }
    }
    //make tab active
    $('ul li').click(function(){
        $('ul li').removeClass("active")
        $("form").css("display","none")
        $(this).addClass("active");
        activator();
    });

});