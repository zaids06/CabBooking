function hireMessage(){
    alert("Your cab has been hired");
}
